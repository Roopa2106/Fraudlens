---
title: "FraudLens: Hybrid Fraud Detection System"
subtitle: "Mini Hackathon 2026 · Problem 3: Fraud Detection System"
---

**Team:** Roopa R · Megha S · Joel George

## 1. Problem understanding

We need to find suspicious financial transactions in a transaction dataset. Four things make this hard:

- **Fraud is rare** (usually under 2%), so plain accuracy is misleading.
- **Labels are often missing**, so a supervised classifier is not always possible.
- **Fraud is relative to the customer.** ₹40,000 is normal for one person and alarming for another.
- **Flags must be explainable**, and false alarms hurt genuine customers.

## 2. Our approach: a hybrid of rules and ML

**Pipeline:** Upload CSV → Clean → Per-customer features → (7 rules + Isolation Forest) → Risk score 0–100 with reasons → Dashboard

**Step 1: Data cleaning.** Convert amounts to numbers, drop missing or negative values, parse timestamps, and sort by time. Columns are mapped in the UI, so the system works on any dataset; only the amount column is required.

**Step 2: Feature engineering (per customer).** Amount z-score against the customer's own average; amount ÷ average; hour and day of week; number of transactions in the last 60 minutes (velocity); minutes since the previous transaction; and how often the customer uses this location or device.

**Step 3: Rule engine (known fraud patterns).**

| Rule | Triggers when | Points |
|---|---|---|
| Amount spike | z-score > 3 | 25 |
| Velocity | ≥ 3 transactions in 60 min | 20 |
| New location | location used in < 15% of the customer's history | 20 |
| Card testing | micro payment (< ₹50), then a large one within 30 min | 20 |
| High value | amount > ₹50,000 | 15 |
| Odd hour | 00:00–05:00 | 10 |
| New device | device rarely used by the customer | 10 |

**Step 4: Isolation Forest (unknown anomalies).** An unsupervised model with 200 trees. Unusual points are isolated with fewer random splits, so they get a higher anomaly score. It needs no labels; we set only the expected fraud share (2%).

**Step 5: Hybrid risk score.**
risk = 100 × [(1 − w) × rule score + w × ML anomaly score], with w = 0.5.
Low < 30 ≤ Medium < 50 ≤ High (flagged). Every flag lists the rules that fired as plain-English reasons.

## 3. Results (sample data: 10,965 transactions, 2% fraud)

| Approach | Precision | Recall | F1 |
|---|---|---|---|
| Rules only | 0.76 | 0.72 | 0.74 |
| **Hybrid (w = 0.5)** | **0.77** | **0.72** | **0.74** |
| ML only | 0.49 | 0.80 | 0.61 |

The hybrid score has a ROC-AUC of **0.988**. ML alone catches more fraud but raises about twice as many false alarms; the rules add precision and explanations. Labels were used **only for evaluation**.

**Insights:** flagged payments average about 13× the normal amount; 60% happen between midnight and 5 AM; 48 customers have repeat flags, which points to compromised accounts.

## 4. Features of the prototype

- Upload any CSV and map its columns; rules switch on based on the columns available.
- KPIs: transactions analysed, number flagged, amount at risk.
- Ranked list of suspicious transactions with reasons, downloadable as CSV.
- Charts: risk distribution, rule frequency, flag rate by hour and category, anomaly scatter.
- Per-customer investigation timeline.
- Evaluation: precision, recall, F1, ROC-AUC, confusion matrix, rules vs ML vs hybrid.
- Live tuning of every threshold and the ML weight.

## 5. Technologies and tools

| Tool | Purpose |
|---|---|
| Python 3 | Core language |
| pandas, NumPy | Data cleaning and feature engineering |
| scikit-learn | Isolation Forest, scaling, evaluation metrics |
| Plotly | Interactive visualisations |
| Streamlit | Web dashboard (prototype UI) |
| Google Colab | Notebook version for running and demonstrating |
| ChatGPT / Claude | Coding assistance; all logic understood and explained by the team |

## 6. Team contribution

| Member | Responsibility |
|---|---|
| Roopa R | Data loading and cleaning, feature engineering, rule engine (7 rules, weights, reasons) |
| Megha S | Isolation Forest model, hybrid risk score, model evaluation |
| Joel George | Streamlit dashboard, Colab notebook, visualisations, presentation |

## 7. Limitations and future work

Thresholds are hand-set. Next steps: a supervised model (XGBoost with class weights) once labelled history is available, real-time scoring through an API, network features such as shared devices or IPs, SHAP explanations, and an analyst feedback loop.
