"""
app.py  -  FraudLens: Hybrid Fraud Detection Dashboard
Run:  streamlit run app.py
"""
import pandas as pd
import plotly.express as px
import streamlit as st

import fraud_engine as fe
from generate_data import generate

st.set_page_config(page_title="FraudLens – Fraud Detection", page_icon="🛡️", layout="wide")

# ------------------------------------------------------------------ Data input
st.sidebar.title("🛡️ FraudLens")
st.sidebar.caption("Rules + Isolation Forest hybrid detector")

src = st.sidebar.radio("Data source", ["Upload CSV", "Use sample data"])
raw = None
if src == "Upload CSV":
    up = st.sidebar.file_uploader("Transaction CSV", type=["csv"])
    if up is not None:
        raw = pd.read_csv(up)
else:
    @st.cache_data
    def _sample():
        return generate()
    raw = _sample()

st.title("FraudLens: Suspicious Transaction Detection")
if raw is None:
    st.info("Upload a transaction CSV from the sidebar, or switch to **Use sample data**.")
    st.stop()

# ------------------------------------------------------------------ Column mapping
# Lets the app work on whatever dataset the organisers hand out.
with st.sidebar.expander("① Map your columns", expanded=(src == "Upload CSV")):
    cols = ["<none>"] + list(raw.columns)

    def pick(label, guesses, required=False):
        guess = next((c for c in raw.columns if c.lower() in guesses), "<none>")
        opts = cols[1:] if required else cols
        return st.selectbox(label, opts, index=opts.index(guess) if guess in opts else 0)

    m = {
        "amount": pick("Amount *", {"amount", "amt", "transaction_amount", "value"}, True),
        "customer_id": pick("Customer / account ID", {"customer_id", "customer", "account", "account_id", "user_id", "nameorig", "card_id"}),
        "timestamp": pick("Date / time", {"timestamp", "date", "datetime", "time", "trans_date_trans_time", "transaction_date"}),
        "merchant_category": pick("Merchant category", {"merchant_category", "category", "merchant_type", "type"}),
        "location": pick("Location / city", {"location", "city", "country", "state"}),
        "device": pick("Device / channel", {"device", "channel", "device_type"}),
        "is_fraud": pick("Fraud label (optional, for evaluation)", {"is_fraud", "fraud", "isfraud", "label", "class"}),
    }

df = pd.DataFrame({k: raw[v] for k, v in m.items() if v != "<none>"})
id_col = next((c for c in raw.columns if "transaction" in c.lower() and "id" in c.lower()), None)
df["transaction_id"] = raw[id_col] if id_col else [f"T{i:06d}" for i in range(len(raw))]

# ------------------------------------------------------------------ Controls
with st.sidebar.expander("② Rule thresholds"):
    rules = {
        "zscore_limit": st.slider("Amount spike: z-score above", 1.5, 6.0, 3.0, 0.5),
        "high_amount": st.number_input("High-value limit (₹)", value=50000, step=5000),
        "night_start": 0,
        "night_end": st.slider("Odd hours: midnight to", 1, 6, 5),
        "velocity_window_min": st.slider("Velocity window (min)", 10, 240, 60, 10),
        "velocity_count": st.slider("Velocity: txns in window ≥", 2, 10, 3),
        "micro_amount": st.number_input("Card-testing micro amount (₹)", value=50, step=10),
    }
with st.sidebar.expander("③ Model settings", expanded=True):
    contamination = st.slider("Expected fraud share (Isolation Forest)", 0.005, 0.10, 0.02, 0.005,
                              format="%.3f")
    ml_weight = st.slider("ML weight in risk score", 0.0, 1.0, 0.5, 0.1,
                          help="0 = rules only, 1 = Isolation Forest only")
    cutoff = st.slider("Flag as suspicious if risk ≥", 20, 90, 50, 5)


@st.cache_data(show_spinner="Scoring transactions…")
def run(df, rules, contamination, ml_weight, cutoff):
    return fe.score(df, rules, contamination, ml_weight, cutoff)


res = run(df, rules, contamination, ml_weight, cutoff)
sus = res[res["suspicious"]]

# ------------------------------------------------------------------ KPIs
k1, k2, k3, k4 = st.columns(4)
k1.metric("Transactions analysed", f"{len(res):,}")
k2.metric("Flagged suspicious", f"{len(sus):,}", f"{len(sus) / len(res):.2%} of total",
          delta_color="off")
k3.metric("Amount at risk", f"₹{sus['amount'].sum():,.0f}",
          f"{sus['amount'].sum() / res['amount'].sum():.1%} of value", delta_color="off")
k4.metric("Avg risk (flagged)", f"{sus['risk_score'].mean():.1f}" if len(sus) else "–")

tab1, tab2, tab3, tab4 = st.tabs(["🚩 Suspicious transactions", "📊 Patterns & insights",
                                  "🔍 Investigate", "✅ Model evaluation"])

# ------------------------------------------------------------------ Tab 1: flagged list
with tab1:
    st.subheader("Flagged transactions, highest risk first")
    show = [c for c in ["transaction_id", "customer_id", "timestamp", "amount", "merchant_category",
                        "location", "device", "risk_score", "risk_level", "reasons"] if c in sus.columns]
    st.dataframe(
        sus[show], width="stretch", hide_index=True, height=420,
        column_config={
            "risk_score": st.column_config.ProgressColumn("Risk", min_value=0, max_value=100, format="%.0f"),
            "amount": st.column_config.NumberColumn("Amount", format="₹%.2f"),
            "reasons": st.column_config.TextColumn("Why flagged", width="large"),
        })
    st.download_button("⬇️ Download flagged list (CSV)", sus[show].to_csv(index=False),
                       "suspicious_transactions.csv", "text/csv")

# ------------------------------------------------------------------ Tab 2: insights
with tab2:
    c1, c2 = st.columns(2)
    with c1:
        fig = px.histogram(res, x="risk_score", color="risk_level", nbins=50,
                           color_discrete_map={"Low": "#2a9d8f", "Medium": "#e9c46a", "High": "#e63946"},
                           title="Distribution of risk scores")
        fig.add_vline(x=cutoff, line_dash="dash", annotation_text="cutoff")
        st.plotly_chart(fig, width="stretch")
    with c2:
        rule_cols = [c for c in fe.RULE_WEIGHTS if c in res.columns]
        hits = sus[rule_cols].sum().rename(index=fe.RULE_TEXT).sort_values()
        fig = px.bar(hits, orientation="h", title="Which rules fire on flagged transactions",
                     labels={"value": "Count", "index": ""})
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, width="stretch")

    c3, c4 = st.columns(2)
    with c3:
        if "hour" in res.columns:
            hr = res.groupby("hour").agg(total=("amount", "size"), flagged=("suspicious", "sum")).reset_index()
            hr["flag_rate_%"] = 100 * hr["flagged"] / hr["total"]
            fig = px.bar(hr, x="hour", y="flag_rate_%", title="Suspicious rate by hour of day")
            st.plotly_chart(fig, width="stretch")
    with c4:
        if "merchant_category" in res.columns:
            cat = res.groupby("merchant_category").agg(flagged=("suspicious", "sum"),
                                                       total=("suspicious", "size")).reset_index()
            cat["flag_rate_%"] = 100 * cat["flagged"] / cat["total"]
            fig = px.bar(cat.sort_values("flag_rate_%"), x="flag_rate_%", y="merchant_category",
                         orientation="h", title="Suspicious rate by merchant category")
            st.plotly_chart(fig, width="stretch")

    plot_df = res.sample(min(len(res), 5000), random_state=1)
    fig = px.scatter(plot_df, x="amount_zscore", y="ml_anomaly_score", color="suspicious",
                     hover_data=[c for c in ["transaction_id", "amount", "reasons"] if c in plot_df],
                     color_discrete_map={True: "#e63946", False: "#9aa5b1"}, opacity=0.6,
                     title="Amount deviation vs ML anomaly score")
    st.plotly_chart(fig, width="stretch")

    # Auto-generated insights
    st.subheader("Key insights")
    notes = []
    if len(sus):
        notes.append(f"Flagged transactions average **₹{sus['amount'].mean():,.0f}**, against "
                     f"₹{res['amount'].mean():,.0f} overall ({sus['amount'].mean() / res['amount'].mean():.1f}× higher).")
        top_rule = hits.idxmax()
        notes.append(f"The most common red flag is **{top_rule.lower()}** "
                     f"({int(hits.max())} of {len(sus)} flagged).")
        if "hour" in res.columns:
            night = sus["hour"].between(0, 5).mean()
            notes.append(f"**{night:.0%}** of flagged transactions happen between midnight and 5 AM.")
        if "customer_id" in sus.columns:
            repeat = sus["customer_id"].value_counts()
            notes.append(f"**{(repeat > 1).sum()}** customers have more than one flagged transaction, "
                         "which suggests compromised accounts rather than one-off errors.")
    for n in notes:
        st.markdown(f"- {n}")

# ------------------------------------------------------------------ Tab 3: drill-down
with tab3:
    if "customer_id" in res.columns and len(sus):
        cust = st.selectbox("Pick a customer with flagged activity", sus["customer_id"].unique())
        hist = res[res["customer_id"] == cust].sort_values("timestamp" if "timestamp" in res else "amount")
        st.caption(f"{len(hist)} transactions · usual spend ≈ ₹{hist['cust_mean_amt'].iloc[0]:,.0f}")
        x = "timestamp" if "timestamp" in hist else "transaction_id"
        fig = px.scatter(hist, x=x, y="amount", color="suspicious", size="risk_score",
                         hover_data=["reasons"], color_discrete_map={True: "#e63946", False: "#2a9d8f"},
                         title=f"Transaction history: {cust}")
        st.plotly_chart(fig, width="stretch")
        st.dataframe(hist[[c for c in show if c in hist]], hide_index=True, width="stretch")
    else:
        st.info("Map a customer ID column to enable customer drill-down.")

# ------------------------------------------------------------------ Tab 4: evaluation
with tab4:
    if "is_fraud" in res.columns:
        from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, roc_auc_score
        y = res["is_fraud"].astype(int)
        p = res["suspicious"].astype(int)
        e1, e2, e3, e4 = st.columns(4)
        e1.metric("Precision", f"{precision_score(y, p, zero_division=0):.2f}",
                  help="Of the flagged, how many were truly fraud")
        e2.metric("Recall", f"{recall_score(y, p, zero_division=0):.2f}",
                  help="Of all fraud, how many we caught")
        e3.metric("F1 score", f"{f1_score(y, p, zero_division=0):.2f}")
        e4.metric("ROC-AUC", f"{roc_auc_score(y, res['risk_score']):.3f}")

        cm = confusion_matrix(y, p)
        fig = px.imshow(cm, text_auto=True, x=["Pred: Normal", "Pred: Fraud"],
                        y=["Actual: Normal", "Actual: Fraud"], color_continuous_scale="Reds",
                        title="Confusion matrix")
        st.plotly_chart(fig, width="stretch")

        st.markdown("**Rules vs ML vs Hybrid** (same cutoff)")
        comp = []
        for name, w in [("Rules only", 0.0), ("Hybrid (current)", ml_weight), ("ML only", 1.0)]:
            r = run(df, rules, contamination, w, cutoff)
            yy, pp = r["is_fraud"].astype(int), r["suspicious"].astype(int)
            comp.append({"Approach": name, "Flagged": int(pp.sum()),
                         "Precision": round(precision_score(yy, pp, zero_division=0), 3),
                         "Recall": round(recall_score(yy, pp, zero_division=0), 3),
                         "F1": round(f1_score(yy, pp, zero_division=0), 3)})
        st.dataframe(pd.DataFrame(comp), hide_index=True, width="stretch")
        st.caption("The fraud label is used **only** for evaluation. Both detectors are unsupervised.")
    else:
        st.info("No fraud label mapped. The detector still works; this tab just needs labels to measure accuracy.")
