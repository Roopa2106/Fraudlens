"""
generate_data.py
Creates a realistic synthetic transaction dataset with ~2% injected fraud.
Use this as backup demo data if the organisers' dataset is late or messy.

Run:  python generate_data.py          -> writes data/transactions.csv
"""
import os
import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

CATEGORIES = ["Grocery", "Fuel", "Restaurant", "Electronics", "Clothing",
              "Travel", "Utilities", "Online Shopping", "Pharmacy", "Entertainment"]
CITIES = ["Bengaluru", "Chennai", "Mumbai", "Delhi", "Hyderabad", "Pune", "Kolkata"]
FOREIGN = ["Dubai", "Singapore", "London", "Lagos", "Bangkok"]
DEVICES = ["Mobile App", "Web", "POS Terminal", "ATM"]


def generate(n_customers: int = 400, days: int = 60, fraud_rate: float = 0.02) -> pd.DataFrame:
    rows = []
    start = pd.Timestamp("2026-08-01")

    for c in range(n_customers):
        cid = f"C{c:04d}"
        home = RNG.choice(CITIES)
        device = RNG.choice(DEVICES[:3], p=[0.6, 0.25, 0.15])
        base_amt = RNG.lognormal(mean=7.0, sigma=0.6)       # typical spend ~ Rs 1,100
        fav_cats = RNG.choice(CATEGORIES, size=4, replace=False)
        n_txn = RNG.poisson(days * 0.4) + 3

        for _ in range(n_txn):
            # Normal behaviour: daytime, home city, usual device, usual categories
            hour = int(np.clip(RNG.normal(14, 5), 0, 23))       # some genuine late-night buys
            ts = start + pd.Timedelta(days=int(RNG.integers(0, days)), hours=hour,
                                      minutes=int(RNG.integers(0, 60)))
            rows.append(dict(
                customer_id=cid, timestamp=ts,
                amount=round(float(base_amt * RNG.lognormal(0, 0.5)), 2),
                merchant_category=RNG.choice(fav_cats),
                # Real customers sometimes travel or switch device -> noise for the detector
                location=RNG.choice(CITIES + FOREIGN) if RNG.random() < 0.04 else home,
                device=RNG.choice(DEVICES) if RNG.random() < 0.06 else device,
                is_fraud=0))

    df = pd.DataFrame(rows)

    # ---- Inject fraud patterns ----
    n_fraud = int(len(df) * fraud_rate)
    victims = RNG.choice(df["customer_id"].unique(), size=n_fraud // 3, replace=False)
    fraud_rows = []
    for v in victims:
        cust = df[df.customer_id == v].iloc[0]
        # Fraud skews to night but not always
        hr = int(RNG.integers(0, 5)) if RNG.random() < 0.6 else int(RNG.integers(9, 22))
        t0 = start + pd.Timedelta(days=int(RNG.integers(5, days)), hours=hr)
        pattern = RNG.choice(["burst", "big_foreign", "card_test"])
        if pattern == "burst":           # many quick high-value buys, new device
            for k in range(4):
                fraud_rows.append(dict(customer_id=v, timestamp=t0 + pd.Timedelta(minutes=4 * k),
                                       amount=round(float(RNG.uniform(4000, 40000)), 2),
                                       merchant_category="Electronics", location=cust.location,
                                       device=RNG.choice(DEVICES[:2]), is_fraud=1))
        elif pattern == "big_foreign":   # one very large foreign txn at night
            fraud_rows.append(dict(customer_id=v, timestamp=t0,
                                   amount=round(float(RNG.uniform(50000, 200000)), 2),
                                   merchant_category=RNG.choice(["Travel", "Online Shopping"]),
                                   location=RNG.choice(FOREIGN), device="Web", is_fraud=1))
        else:                            # card testing: tiny amounts then a big one
            for k in range(3):
                fraud_rows.append(dict(customer_id=v, timestamp=t0 + pd.Timedelta(minutes=2 * k),
                                       amount=round(float(RNG.uniform(1, 20)), 2),
                                       merchant_category="Online Shopping", location=cust.location,
                                       device="Web", is_fraud=1))
            fraud_rows.append(dict(customer_id=v, timestamp=t0 + pd.Timedelta(minutes=8),
                                   amount=round(float(RNG.uniform(30000, 90000)), 2),
                                   merchant_category="Electronics", location=RNG.choice(FOREIGN),
                                   device="Web", is_fraud=1))

    df = pd.concat([df, pd.DataFrame(fraud_rows)], ignore_index=True)
    df = df.sort_values("timestamp").reset_index(drop=True)
    df.insert(0, "transaction_id", [f"T{i:06d}" for i in range(len(df))])
    return df


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    data = generate()
    data.to_csv("data/transactions.csv", index=False)
    print(f"Saved {len(data):,} transactions, {data.is_fraud.sum()} fraud "
          f"({data.is_fraud.mean():.2%}) -> data/transactions.csv")
