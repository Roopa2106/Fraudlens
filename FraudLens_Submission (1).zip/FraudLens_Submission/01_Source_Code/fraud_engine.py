"""
fraud_engine.py
Core logic: feature engineering -> rule-based flags -> Isolation Forest -> hybrid risk score.
Kept separate from the UI so it can be tested and explained on its own.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# Default thresholds (all adjustable from the app sidebar)
DEFAULT_RULES = {
    "zscore_limit": 3.0,       # amount > 3 std devs above the customer's own mean
    "high_amount": 50000.0,    # absolute high-value limit (Rs)
    "night_start": 0,          # odd-hour window
    "night_end": 5,
    "velocity_window_min": 60, # rapid-fire window
    "velocity_count": 3,       # >= this many txns inside the window
    "micro_amount": 50.0,      # card-testing: tiny txn amount
}

RULE_WEIGHTS = {               # how many risk points each rule contributes
    "R1_amount_spike": 25,
    "R2_high_value": 15,
    "R3_odd_hour": 10,
    "R4_velocity": 20,
    "R5_new_location": 20,
    "R6_new_device": 10,
    "R7_card_testing": 20,
}

RULE_TEXT = {
    "R1_amount_spike": "Amount far above customer's usual spend",
    "R2_high_value": "Very high transaction value",
    "R3_odd_hour": "Made at an unusual hour",
    "R4_velocity": "Many transactions in a short time",
    "R5_new_location": "Location never used by this customer",
    "R6_new_device": "Device/channel never used by this customer",
    "R7_card_testing": "Tiny 'test' payment just before a larger one",
}


def engineer_features(df: pd.DataFrame, rules: dict) -> pd.DataFrame:
    """Add behavioural features. Works with whichever optional columns exist."""
    d = df.copy()
    has = lambda c: c in d.columns

    d["amount"] = pd.to_numeric(d["amount"], errors="coerce")
    d = d.dropna(subset=["amount"])
    d = d[d["amount"] >= 0]

    if has("timestamp"):
        d["timestamp"] = pd.to_datetime(d["timestamp"], errors="coerce")
        d = d.dropna(subset=["timestamp"]).sort_values("timestamp")
        d["hour"] = d["timestamp"].dt.hour
        d["day_of_week"] = d["timestamp"].dt.dayofweek

    if not has("customer_id"):
        d["customer_id"] = "ALL"   # fall back to population-level stats

    g = d.groupby("customer_id")["amount"]
    d["cust_mean_amt"] = g.transform("mean")
    d["cust_std_amt"] = g.transform("std").fillna(0)
    # Customer-level z-score; fall back to global std for customers with 1 txn
    global_std = d["amount"].std()
    std = d["cust_std_amt"].replace(0, global_std)
    d["amount_zscore"] = (d["amount"] - d["cust_mean_amt"]) / std
    d["amount_to_avg_ratio"] = d["amount"] / d["cust_mean_amt"].replace(0, np.nan)
    d["cust_txn_count"] = g.transform("count")

    if has("timestamp"):
        # Transactions by the same customer within the velocity window (rolling count)
        win = f"{int(rules['velocity_window_min'])}min"
        d = d.set_index("timestamp")
        d["txn_in_window"] = (d.groupby("customer_id")["amount"]
                                .transform(lambda s: s.rolling(win).count()))
        d = d.reset_index()
        d["mins_since_prev"] = (d.groupby("customer_id")["timestamp"].diff()
                                  .dt.total_seconds().div(60))

    # "Is this the customer's usual location/device?" -> frequency share
    for col in ["location", "device"]:
        if has(col):
            counts = d.groupby(["customer_id", col])[col].transform("count")
            d[f"{col}_share"] = counts / d["cust_txn_count"]
    return d


def apply_rules(d: pd.DataFrame, rules: dict) -> pd.DataFrame:
    has = lambda c: c in d.columns
    flags = pd.DataFrame(index=d.index)
    flags["R1_amount_spike"] = d["amount_zscore"] > rules["zscore_limit"]
    flags["R2_high_value"] = d["amount"] > rules["high_amount"]
    if has("hour"):
        flags["R3_odd_hour"] = d["hour"].between(rules["night_start"], rules["night_end"])
    if has("txn_in_window"):
        flags["R4_velocity"] = d["txn_in_window"] >= rules["velocity_count"]
    if has("location_share"):
        flags["R5_new_location"] = (d["location_share"] < 0.15) & (d["cust_txn_count"] >= 5)
    if has("device_share"):
        flags["R6_new_device"] = (d["device_share"] < 0.15) & (d["cust_txn_count"] >= 5)
    if has("mins_since_prev"):
        # A big payment that follows a micro payment from the same customer within 30 min
        prev_amt = d.groupby("customer_id")["amount"].shift(1)
        is_micro = d["amount"] < rules["micro_amount"]
        next_is_micro_chain = (prev_amt < rules["micro_amount"]) & (d["mins_since_prev"] <= 30)
        flags["R7_card_testing"] = (is_micro & (d["txn_in_window"] >= 2)) | \
                                   (next_is_micro_chain & (d["amount"] > 10 * rules["micro_amount"]))

    flags = flags.fillna(False).astype(bool)
    d = d.join(flags)
    d["rule_points"] = sum(flags[c] * RULE_WEIGHTS[c] for c in flags.columns)
    d["rules_triggered"] = flags.sum(axis=1)
    d["reasons"] = flags.apply(lambda r: "; ".join(RULE_TEXT[c] for c in flags.columns if r[c]),
                               axis=1)
    return d


def apply_isolation_forest(d: pd.DataFrame, contamination: float) -> pd.DataFrame:
    """Unsupervised anomaly detection on behavioural features."""
    candidates = ["amount", "amount_zscore", "amount_to_avg_ratio", "hour",
                  "txn_in_window", "mins_since_prev", "location_share", "device_share"]
    feats = [c for c in candidates if c in d.columns]
    X = d[feats].copy()
    X["amount"] = np.log1p(X["amount"])                 # tame the heavy right tail
    X = X.fillna(X.median(numeric_only=True)).fillna(0)
    Xs = StandardScaler().fit_transform(X)

    model = IsolationForest(n_estimators=200, contamination=contamination, random_state=42)
    model.fit(Xs)
    raw = -model.score_samples(Xs)                       # higher = more anomalous
    d["ml_anomaly_score"] = (raw - raw.min()) / (raw.max() - raw.min() + 1e-9)
    d["ml_flag"] = model.predict(Xs) == -1
    d.attrs["ml_features"] = feats
    return d


def score(df: pd.DataFrame, rules: dict = None, contamination: float = 0.02,
          ml_weight: float = 0.5, risk_cutoff: float = 50) -> pd.DataFrame:
    """Full pipeline. Risk score 0-100 = blend of rule points and ML anomaly score."""
    rules = {**DEFAULT_RULES, **(rules or {})}
    d = engineer_features(df, rules)
    d = apply_rules(d, rules)
    d = apply_isolation_forest(d, contamination)

    max_pts = sum(RULE_WEIGHTS.values())
    rule_score = np.clip(d["rule_points"] / (0.5 * max_pts), 0, 1)  # saturates at half the points
    d["risk_score"] = (100 * ((1 - ml_weight) * rule_score + ml_weight * d["ml_anomaly_score"])).round(1)
    d["risk_level"] = pd.cut(d["risk_score"], [-1, 30, risk_cutoff, 101],
                             labels=["Low", "Medium", "High"])
    d["suspicious"] = d["risk_score"] >= risk_cutoff
    d.loc[d["ml_flag"] & (d["reasons"] == ""), "reasons"] = "Unusual overall pattern (ML)"
    return d.sort_values("risk_score", ascending=False)
