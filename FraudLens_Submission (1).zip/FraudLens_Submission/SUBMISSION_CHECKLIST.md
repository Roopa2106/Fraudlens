# FraudLens: Submission Checklist
**Team:** Roopa R · Megha S · Joel George

## What's in this folder

| Folder / file | Hackathon requirement it covers |
|---|---|
| `01_Source_Code/` | **Source code** |
| `02_Colab_Notebook/FraudLens_Colab.ipynb` | **Working prototype.** Upload to Colab, then Runtime → Run all. |
| `03_Approach_and_Technologies.pdf` | **Brief explanation of approach** + **Technologies and tools used** |
| `04_Presentation/FraudLens_Presentation.pdf` | **Final presentation** |
| `05_Sample_Output/` | Proof of a working run: flagged transactions CSV + the executed notebook with all outputs |

## Steps
1. **Prototype:** open `FraudLens_Colab.ipynb` in Colab and Run all. Show the outputs live, or run Step 10 for the Streamlit dashboard link.
   - If you have their dataset: set `USE_SAMPLE = False`, fix `COLUMN_MAP`, and upload their CSV.
2. **Present** `FraudLens_Presentation.pdf` (about 5 minutes), then the live demo.
3. **Submit** this whole folder, zipped.

## Run locally instead of Colab
```
cd 01_Source_Code
pip install -r requirements.txt
streamlit run app.py
```
